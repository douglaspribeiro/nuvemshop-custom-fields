# Campos Personalizados — descrição para a loja de aplicativos

Descrição curta:

Campos, imagens e pedidos personalizados para sua loja.

## Introdução

Venda produtos personalizados com os detalhes que sua operação precisa. Com o Campos Personalizados, seu cliente informa nomes, mensagens e escolhas na página do produto, antes de adicionar ao carrinho. Do jeito que seu cliente escolheu: os detalhes acompanham a compra e ficam registrados no próprio item do pedido. Ao consultar a venda na Nuvemshop, você encontra nomes, mensagens e opções para preparar cada produto com mais clareza.

Ideal para papelaria, presentes, lembrancinhas, roupas, acessórios e outros produtos feitos sob encomenda. Comece com o plano gratuito e amplie a capacidade conforme sua loja cresce.

## O que é o Campos Personalizados?

O Campos Personalizados é um aplicativo para Nuvemshop que permite ao lojista configurar campos adicionais por produto. Você escolhe quais informações solicitar e organiza as opções para que o comprador explique como deseja receber seu produto.

Além de textos e listas, é possível oferecer opções com imagens cadastradas pelo lojista: capas de caderno, estampas, modelos ou outras escolhas visuais. O comprador compara as imagens e seleciona a opção desejada.

## Como funciona o Campos Personalizados?

- Instale o aplicativo e autorize a conexão com sua loja Nuvemshop.
- Escolha o produto que deseja personalizar.
- Configure os campos, as orientações e as opções disponíveis.
- Use os modelos por nicho para começar uma configuração ou crie seus próprios campos.
- O comprador preenche os dados na página do produto.
- As respostas acompanham o item no carrinho e na finalização da compra.
- Depois da compra, consulte a venda na Nuvemshop: os detalhes da personalização ficam registrados no próprio item vendido.
- Consulte no painel do aplicativo os pedidos recentes com personalização.

## Quais são as funcionalidades do Campos Personalizados?

- **Texto e área de texto:** receba nomes, frases, dedicatórias e instruções.
- **Campos numéricos:** solicite informações em formato de número.
- **Listas de seleção:** ofereça opções predefinidas para o comprador escolher.
- **Opções com imagens:** cadastre imagens de capas, estampas e modelos, com miniaturas e possibilidade de ampliação.
- **Campos obrigatórios:** defina quais informações precisam ser preenchidas antes da compra.
- **Orientações e validações:** configure textos de exemplo, limite de caracteres e regras de preenchimento.
- **Configuração por produto:** organize os campos e sua ordem de exibição conforme cada item do catálogo.
- **Modelos por nicho:** comece a configuração a partir de modelos disponíveis no painel, conforme o plano.
- **Aparência:** ajuste as cores dos textos dos campos no produto, no carrinho e no checkout.
- **Personalização no fluxo de compra:** mantenha os dados preenchidos associados ao item no carrinho, no checkout e no pedido. Para opções com imagens, a miniatura pode ser exibida no carrinho e no checkout enquanto a opção continuar disponível.
- **Detalhes no item vendido:** depois que o cliente finaliza a compra, nomes, mensagens e opções escolhidas ficam registrados junto ao produto no pedido. Ao abrir a venda no painel da Nuvemshop, o lojista pode consultar esses detalhes para preparar o produto como o cliente pediu.
- **Pedidos personalizados:** consulte os pedidos recentes e as informações de personalização pelo painel do aplicativo.

### Upload de imagens pelo comprador — em desenvolvimento

Estamos desenvolvendo um campo para que o próprio comprador envie uma foto, logotipo ou arte ao personalizar o produto. Esse recurso ainda não está disponível e é diferente da seleção de imagens já cadastradas pelo lojista.

Quando disponibilizado, terá limites e disponibilidade conforme o plano contratado. Os limites específicos e a data de lançamento ainda serão informados.

## Vantagens de instalar o Campos Personalizados

- Receba informações de personalização no momento da escolha do produto.
- Dê ao comprador opções claras para nomes, mensagens, acabamentos e modelos.
- Facilite a escolha visual de capas e estampas.
- Prepare cada produto como seu cliente escolheu, com os detalhes registrados no próprio item da venda.
- Diminua a necessidade de confirmar informações por mensagens separadas.
- Comece gratuitamente e escolha uma capacidade adequada ao seu catálogo.

## Planos e preços para lojistas Nuvemshop

Os valores abaixo são mensais para lojas brasileiras. Os recursos e os limites completos estão disponíveis no aplicativo e na página de preços.

- **Free — gratuito:** 1 produto personalizado e 1 campo por produto. Sem opções com imagens.
- **Essencial — R$ 19,99/mês:** até 10 produtos personalizados e 3 campos por produto. Permite opções com imagens em 1 produto, com até 3 opções de imagem por campo.
- **Pro — R$ 29,99/mês:** até 50 produtos personalizados e campos ilimitados. Permite imagens nos 50 produtos, com até 8 opções de imagem por campo.
- **Ultra — R$ 59,90/mês:** produtos personalizados e campos ilimitados. Permite imagens em produtos ilimitados, com até 25 opções de imagem por campo, além de atendimento prioritário.

Os limites de imagens acima se referem às opções cadastradas pelo lojista. Eles não representam limites do futuro upload pelo comprador.

Preços e detalhes: https://campos-personalizados.wzhub.pro/precos/

## Como integrar o Campos Personalizados com a Nuvemshop?

1. Clique em **Instalar aplicativo**.
2. Autorize as permissões solicitadas pela Nuvemshop.
3. Acesse o painel do aplicativo pela sua loja.
4. Escolha um produto e configure seus campos ou use um modelo disponível.
5. Salve a configuração e confira o produto na vitrine.

A integração usa a autorização da própria Nuvemshop. Os pedidos são finalizados no fluxo de compra da sua loja.

## Suporte ao lojista

Precisa de ajuda para configurar seus campos ou escolher um plano?

- Central de suporte no aplicativo: https://campos-personalizados.wzhub.pro/support/
- E-mail: contato@wzhub.pro
- Site: https://campos-personalizados.wzhub.pro/
